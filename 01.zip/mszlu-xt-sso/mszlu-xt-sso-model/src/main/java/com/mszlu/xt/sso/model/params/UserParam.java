package com.mszlu.xt.sso.model.params;

import lombok.Data;

@Data
public class UserParam {
}
