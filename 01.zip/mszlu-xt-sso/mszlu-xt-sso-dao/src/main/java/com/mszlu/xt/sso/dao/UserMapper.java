package com.mszlu.xt.sso.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mszlu.xt.sso.dao.data.User;

public interface UserMapper extends BaseMapper<User> {
}
